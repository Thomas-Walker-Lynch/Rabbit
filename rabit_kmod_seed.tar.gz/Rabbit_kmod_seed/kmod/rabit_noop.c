// rabit_noop.c — IPv4-only, no-op netfilter interposer for Debian 12 (Bookworm)
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/skbuff.h>
#include <linux/atomic.h>
#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>

static atomic64_t cnt_local_out  = ATOMIC_LONG_INIT(0);
static atomic64_t cnt_postroute  = ATOMIC_LONG_INIT(0);

static unsigned int rabit_v4_hook(void *priv, struct sk_buff *skb, const struct nf_hook_state *st) {
  if (st->hook == NF_INET_LOCAL_OUT)        atomic64_inc(&cnt_local_out);
  else if (st->hook == NF_INET_POST_ROUTING) atomic64_inc(&cnt_postroute);
  return NF_ACCEPT; // pass through untouched
}

static struct nf_hook_ops rabit_ops[] = {
  { .hook = rabit_v4_hook, .pf = NFPROTO_IPV4, .hooknum = NF_INET_LOCAL_OUT,    .priority = NF_IP_PRI_FIRST },
  { .hook = rabit_v4_hook, .pf = NFPROTO_IPV4, .hooknum = NF_INET_POST_ROUTING, .priority = NF_IP_PRI_FIRST },
};

static int __init rabit_init(void) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,3,0)
  int ret = nf_register_net_hooks(&init_net, rabit_ops, ARRAY_SIZE(rabit_ops));
#else
  int ret = nf_register_hooks(rabit_ops, ARRAY_SIZE(rabit_ops));
#endif
  if (ret) pr_err("rabit_noop: register failed: %d\n", ret);
  else     pr_info("rabit_noop: loaded (IPv4 no-op)\n");
  return ret;
}

static void __exit rabit_exit(void) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,3,0)
  nf_unregister_net_hooks(&init_net, rabit_ops, ARRAY_SIZE(rabit_ops));
#else
  nf_unregister_hooks(rabit_ops, ARRAY_SIZE(rabit_ops));
#endif
  pr_info("rabit_noop: stats v4 local_out=%lld postrouting=%lld\n",
          (long long)atomic64_read(&cnt_local_out),
          (long long)atomic64_read(&cnt_postroute));
}

module_init(rabit_init);
module_exit(rabit_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rabit");
MODULE_DESCRIPTION("Rabit IPv4 no-op netfilter interposer");
